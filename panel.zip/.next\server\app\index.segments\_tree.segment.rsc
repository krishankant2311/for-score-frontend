:HL["/admin/_next/static/chunks/0px0eusevds45.css","style"]
:HL["/admin/_next/static/chunks/0g5vl7dl-_arj.css","style"]
:HL["/admin/_next/static/media/797e433ab948586e-s.p.08e28id.o-okb.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/admin/_next/static/media/caa3a2e1cccd8315-s.p.09~u27dqhyhd6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"Dh0ENvIf4vR-XpF4qtN3j"}
