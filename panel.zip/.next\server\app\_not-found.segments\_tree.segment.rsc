:HL["/admin/_next/static/chunks/0px0eusevds45.css","style"]
:HL["/admin/_next/static/chunks/0g5vl7dl-_arj.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"Dh0ENvIf4vR-XpF4qtN3j"}
