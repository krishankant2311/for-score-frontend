globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Dh0ENvIf4vR-XpF4qtN3j/_buildManifest.js",
    "static/Dh0ENvIf4vR-XpF4qtN3j/_ssgManifest.js",
    "static/Dh0ENvIf4vR-XpF4qtN3j/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/014wsfxx5mwy7.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/0db1g7el_ujh5.js",
    "static/chunks/07uz2g0_38qia.js",
    "static/chunks/turbopack-0~a1u.4ohb08o.js"
  ]
};
