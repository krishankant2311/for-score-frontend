1:"$Sreact.fragment"
2:I[39756,["/admin/_next/static/chunks/15vta0mnzqrbb.js","/admin/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[37457,["/admin/_next/static/chunks/15vta0mnzqrbb.js","/admin/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"CqIFXFAA3JWYW6GnIqRuN"}
