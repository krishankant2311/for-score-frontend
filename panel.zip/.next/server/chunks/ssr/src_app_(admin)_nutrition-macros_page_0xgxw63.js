module.exports=[88289,a=>{"use strict";var b=a.i(72131),c=a.i(50944);a.s(["default",0,function(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{a.replace("/foods")},[a]),null}])}];

//# sourceMappingURL=src_app_%28admin%29_nutrition-macros_page_0xgxw63.js.map