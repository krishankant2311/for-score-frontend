module.exports=[75922,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_foods_%5Bid%5D_edit_page_actions_125our~.js.map