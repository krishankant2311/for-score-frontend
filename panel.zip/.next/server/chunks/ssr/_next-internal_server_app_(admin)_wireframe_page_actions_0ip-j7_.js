module.exports=[70238,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_wireframe_page_actions_0ip-j7_.js.map