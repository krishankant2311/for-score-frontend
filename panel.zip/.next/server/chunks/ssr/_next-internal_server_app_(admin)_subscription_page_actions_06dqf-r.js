module.exports=[37837,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_subscription_page_actions_06dqf-r.js.map