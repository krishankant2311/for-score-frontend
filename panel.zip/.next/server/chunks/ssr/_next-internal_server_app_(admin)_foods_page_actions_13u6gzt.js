module.exports=[47150,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_foods_page_actions_13u6gzt.js.map