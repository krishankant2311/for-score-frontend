module.exports=[49980,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_nutrition-macros_page_actions_00o-hm0.js.map