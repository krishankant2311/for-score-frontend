module.exports=[27671,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_notification_page_actions_0z164v..js.map