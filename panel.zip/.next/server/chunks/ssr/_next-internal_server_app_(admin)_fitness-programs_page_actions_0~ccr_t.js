module.exports=[1304,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_fitness-programs_page_actions_0~ccr_t.js.map