module.exports=[27964,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_notification_%5Bid%5D_edit_page_actions_0ya.-cq.js.map