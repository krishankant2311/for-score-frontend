module.exports=[56934,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_fitness-programs_new_page_actions_0lieu69.js.map