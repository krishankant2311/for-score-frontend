module.exports=[67409,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_faq_%5Bid%5D_edit_page_actions_074d0et.js.map