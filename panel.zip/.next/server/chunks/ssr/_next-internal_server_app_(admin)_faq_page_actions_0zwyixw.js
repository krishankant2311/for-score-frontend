module.exports=[16189,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_faq_page_actions_0zwyixw.js.map