module.exports=[61816,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_active-users-today_page_actions_0-33i50.js.map