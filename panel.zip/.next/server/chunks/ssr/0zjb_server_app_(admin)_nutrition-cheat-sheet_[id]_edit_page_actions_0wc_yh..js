module.exports=[6014,(a,b,c)=>{}];

//# sourceMappingURL=0zjb_server_app_%28admin%29_nutrition-cheat-sheet_%5Bid%5D_edit_page_actions_0wc_yh..js.map