module.exports=[26444,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_faq_new_page_actions_0ifjfte.js.map