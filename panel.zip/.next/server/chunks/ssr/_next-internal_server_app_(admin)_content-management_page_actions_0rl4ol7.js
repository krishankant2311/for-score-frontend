module.exports=[2830,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_content-management_page_actions_0rl4ol7.js.map