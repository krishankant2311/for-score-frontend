module.exports=[68730,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_fitness-programs_%5Bid%5D_page_actions_0807iy6.js.map