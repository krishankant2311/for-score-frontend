module.exports=[7737,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_foods_new_page_actions_0j1zevx.js.map