module.exports=[23730,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_feedback_page_actions_0phf19x.js.map