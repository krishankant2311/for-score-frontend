module.exports=[99443,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_exercise-library_page_actions_0ih1m4t.js.map