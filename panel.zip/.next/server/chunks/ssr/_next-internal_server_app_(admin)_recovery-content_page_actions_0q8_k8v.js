module.exports=[80069,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_recovery-content_page_actions_0q8_k8v.js.map