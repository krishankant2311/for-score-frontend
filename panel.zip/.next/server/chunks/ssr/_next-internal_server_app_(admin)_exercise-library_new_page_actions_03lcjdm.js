module.exports=[67687,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_exercise-library_new_page_actions_03lcjdm.js.map