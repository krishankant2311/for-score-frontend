module.exports=[45180,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_nutrition-cheat-sheet_page_actions_0ncn851.js.map