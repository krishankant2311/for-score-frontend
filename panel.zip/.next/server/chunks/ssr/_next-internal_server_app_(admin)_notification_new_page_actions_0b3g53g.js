module.exports=[17402,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_notification_new_page_actions_0b3g53g.js.map