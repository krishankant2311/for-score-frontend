module.exports=[57474,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_stretch-programs_page_actions_11r0-k9.js.map