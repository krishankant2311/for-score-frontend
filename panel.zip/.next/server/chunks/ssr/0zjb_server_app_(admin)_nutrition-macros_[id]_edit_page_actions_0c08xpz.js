module.exports=[78685,(a,b,c)=>{}];

//# sourceMappingURL=0zjb_server_app_%28admin%29_nutrition-macros_%5Bid%5D_edit_page_actions_0c08xpz.js.map