module.exports=[71709,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_onboarding_page_actions_0xq9~-~.js.map