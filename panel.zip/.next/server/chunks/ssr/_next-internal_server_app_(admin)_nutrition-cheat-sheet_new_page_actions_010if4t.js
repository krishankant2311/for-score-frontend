module.exports=[92408,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_nutrition-cheat-sheet_new_page_actions_010if4t.js.map