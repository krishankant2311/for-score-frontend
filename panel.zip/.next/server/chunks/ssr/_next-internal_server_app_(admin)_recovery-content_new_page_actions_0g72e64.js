module.exports=[88457,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_recovery-content_new_page_actions_0g72e64.js.map