module.exports=[47477,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_stretch-programs_new_page_actions_0v_tv8w.js.map