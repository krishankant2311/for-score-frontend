globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/CqIFXFAA3JWYW6GnIqRuN/_buildManifest.js",
    "static/CqIFXFAA3JWYW6GnIqRuN/_ssgManifest.js",
    "static/CqIFXFAA3JWYW6GnIqRuN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/0spcef.~5wmr0.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0db1g7el_ujh5.js",
    "static/chunks/07uz2g0_38qia.js",
    "static/chunks/turbopack-0mqjl~j0r-nd1.js"
  ]
};
